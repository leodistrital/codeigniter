<?php
echo $this->include('components/general/head');
echo $this->include('components/login/formnuevo');
echo $this->include('components/general/footer');