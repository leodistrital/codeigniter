<?php
echo $this->include('components/general/head');
echo $this->include('components/panel/panelnuevos');
echo $this->include('components/general/footer');