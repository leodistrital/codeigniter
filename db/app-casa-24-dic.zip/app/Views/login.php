<?php
echo $this->include('components/general/head');
echo $this->include('components/login/formlogin');
echo $this->include('components/general/footer');