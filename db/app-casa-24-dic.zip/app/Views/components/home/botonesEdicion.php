<!--Edition PSB-->
<div class="gDiv contEdition ">
    <div class="maxW">
        <div class="editionPSB st2" style="padding-left: 15px;">
            <h2 class="tituloedicion2022">
                <h2>Edición <?=$versionConsulta?> </h2>
                <div class="divbotonhome">
                    <dv>
                        <a href="https://premiosimonbolivar.com/pdf/<?=$pdfdiscursojurado  ?>"
                            class="btnBigIco bg1 icoA openPdf">
                            <span class="linkactadiscursohime">LEER DISCURSO DEL JURADO</span>
                        </a>
                    </dv>
                    <dv>
                        <a href="https://premiosimonbolivar.com/pdf/<?= $pdfactajurado ?>"
                            class="btnBigIco bg3 icoA openPdf">
                            <span class="linkactadiscursohime">ACTA DEL JURADO</span>
                        </a>
                    </dv>
                </div>
        </div>
    </div>
</div>
<!--End Edition PSB-->