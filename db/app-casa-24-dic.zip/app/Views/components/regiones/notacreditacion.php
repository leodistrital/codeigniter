<div class="sectExtra galeria">
    <div class="contExt">
        <h2><?=traduccirlabeldb('Las acreditaciones para el BAM en las regiones no tienen costo'); ?></h2>
    </div>
</div>