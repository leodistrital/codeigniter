<!--Prefooter Section Home-->
<section class="prefooterHSection">
    <div class="sliderPrefooter">
        <div class="gSlide">
            <div class="vAlign">
                <div>
                    <img src="<?=$logos?>" alt="">
                </div>
            </div>
        </div>
    </div>
</section>
<!--End Small Section Home-->