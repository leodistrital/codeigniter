 <div class="maxW">
     <div class="contIntern">
         <div class="gContent">
             <div class="topInfo">
                 <h2 class="gTitle"><?= $contenidogocategoria['nom_cat'] ?></h2>
                 <div class="gIntro"><?= $contenidogocategoria['des_cat'] ?></div>
             </div>
         </div>
     </div>
 </div>
 <!--Info superior-->