 <div class="cRight">
     <section class="contWinOld gAnimated fadeIn">

         <h2 class="title1">Trabajo deportivo</h2>
         <!-- <hr class="gLine w2 bg2"> -->
         <div class="listWOld">
             <article class="itemWOld">
                 <h3 class="title1 s1">Radio</h3>
                 <!-- <hr class="gLine bg2"> -->
                 <h4 class="title1 s2"></h4>
                 <div class="title2 s1">DESIERTO</div>
                 <p class="title2 s2"></p>
             </article>
             <article class="itemWOld">
                 <h3 class="title1 s1">Televisión</h3>
                 <!-- <hr class="gLine bg2"> -->
                 <h4 class="title1 s2">Boxeador Dagua</h4>
                 <div class="title2 s1">CARMEN ANDREA RENGIFO</div>
                 <p class="title2 s2">telepacífico</p>
             </article>
             <article class="itemWOld">
                 <h3 class="title1 s1">Prensa</h3>
                 <!-- <hr class="gLine bg2"> -->
                 <h4 class="title1 s2">Vuelta a la manzana</h4>
                 <div class="title2 s1">MAURICIO BAYONA</div>
                 <p class="title2 s2">revista soho</p>
             </article>
         </div>
     </section>
     <section class="contWinOld gAnimated fadeIn">
         <h2 class="title1">Trabajo cultural</h2>
         <!-- <hr class="gLine w2 bg2"> -->
         <div class="listWOld">
             <article class="itemWOld">
                 <h3 class="title1 s1">Radio</h3>
                 <!-- <hr class="gLine bg2"> -->
                 <h4 class="title1 s2">La historia del mundo</h4>
                 <div class="title2 s1">DIANA URIBE FORERO</div>
                 <p class="title2 s2">radionet</p>
             </article>
             <article class="itemWOld">
                 <h3 class="title1 s1">Televisión</h3>
                 <!-- <hr class="gLine bg2"> -->
                 <h4 class="title1 s2">Vámonos caminando</h4>
                 <div class="title2 s1">ALBERTO SALCEDO RAMOS Y FRANCISCO PABÓN ARIZA</div>
                 <p class="title2 s2">señal colombia</p>
             </article>
             <article class="itemWOld">
                 <h3 class="title1 s1">Prensa</h3>
                 <!-- <hr class="gLine bg2"> -->
                 <h4 class="title1 s2">El viacrucis feliz de Dereck Walcott en el Caribe colombiano</h4>
                 <div class="title2 s1">ARIEL CASTILLO</div>
                 <p class="title2 s2">revista aguaita</p>
             </article>
         </div>
     </section>
     <section class="contWinOld gAnimated fadeIn">
         <h2 class="title1">Fotografía</h2>
         <!-- <hr class="gLine w2 bg2"> -->
         <div class="listWOld">
             <article class="itemWOld">
                 <h3 class="title1 s1">Prensa</h3>
                 <!-- <hr class="gLine bg2"> -->
                 <h4 class="title1 s2">Urgencias de combate</h4>
                 <div class="title2 s1">JULIÁN ALBERTO LINEROS</div>
                 <p class="title2 s2">revista cromos</p>
             </article>
         </div>
     </section>
     <section class="contWinOld gAnimated fadeIn">
         <h2 class="title1">Entrevista</h2>
         <!-- <hr class="gLine w2 bg2"> -->
         <div class="listWOld">
             <article class="itemWOld">
                 <h3 class="title1 s1">Radio</h3>
                 <!-- <hr class="gLine bg2"> -->
                 <h4 class="title1 s2">Entrevista al expresidente Bill Clinton, La FM</h4>
                 <div class="title2 s1">JULIO SÁNCHEZ CRISTO</div>
                 <p class="title2 s2">rcn radio</p>
             </article>
             <article class="itemWOld">
                 <h3 class="title1 s1">Televisión</h3>
                 <!-- <hr class="gLine bg2"> -->
                 <h4 class="title1 s2">Entrevista a Juan Carlos Riascos, programa La Lechuza</h4>
                 <div class="title2 s1">D‘arcy Quinn Reyes</div>
                 <p class="title2 s2">canal caracol</p>
             </article>
             <article class="itemWOld">
                 <h3 class="title1 s1">Prensa</h3>
                 <!-- <hr class="gLine bg2"> -->
                 <h4 class="title1 s2">La mujer del presidente</h4>
                 <div class="title2 s1">GERMÁN SANTAMARÍA</div>
                 <p class="title2 s2">revista diners</p>
             </article>
         </div>
     </section>
     <section class="contWinOld gAnimated fadeIn">
         <h2 class="title1">Cubrimiento de una noticia</h2>
         <!-- <hr class="gLine w2 bg2"> -->
         <div class="listWOld">
             <article class="itemWOld">
                 <h3 class="title1 s1">Radio</h3>
                 <!-- <hr class="gLine bg2"> -->
                 <h4 class="title1 s2">Fin del proceso de paz</h4>
                 <div class="title2 s1">NARDA GÓMEZ ESLAVA, RENÉ ROJAS Y LUIS GUILLERMO TROYA</div>
                 <p class="title2 s2">todelar</p>
             </article>
             <article class="itemWOld">
                 <h3 class="title1 s1">Televisión</h3>
                 <!-- <hr class="gLine bg2"> -->
                 <h4 class="title1 s2">Diego Fernando Serna Alzate, el infiltrado, Noticias RCN</h4>
                 <div class="title2 s1">ALVARO GARCÍA, CLARA ELVIRA OSPINA, JUAN CARLOS GIRALDO, MARIA DEL
                     ROSARIO ARRÁZOLA, WILSON BARCO, CLAUDIA RIOS, FRANCISCO MORALES, JUAN FERNANDO TABARES,
                     ALFREDO BUSTILLO, JUAN CARLOS RUIZ Y EDWIN GUTIERREZ</div>
                 <p class="title2 s2">canal rcn</p>
             </article>
             <article class="itemWOld">
                 <h3 class="title1 s1">Prensa</h3>
                 <!-- <hr class="gLine bg2"> -->
                 <h4 class="title1 s2">Llora Caldas</h4>
                 <div class="title2 s1">OLGA LUCIA PÉREZ, MAURICIO ANTONIO OCAMPO, ALEXANDER MARÍN, PEDRO PABLO
                     MEJÍA, FREDDY ARANGO Y MARTHA ELENA MONROY</div>
                 <p class="title2 s2">la patria</p>
             </article>
         </div>
     </section>
     <section class="contWinOld gAnimated fadeIn">
         <h2 class="title1">Crónica o reportaje</h2>
         <!-- <hr class="gLine w2 bg2"> -->
         <div class="listWOld">
             <article class="itemWOld">
                 <h3 class="title1 s1">Radio</h3>
                 <!-- <hr class="gLine bg2"> -->
                 <h4 class="title1 s2">Las cosas que salen bien en Colombia, Radio Sucesos RCN</h4>
                 <div class="title2 s1">FRANCISCO TULANDE, JUAN MANUEL RUIZ, PILAR CASTAÑO, JORGE EUSEBIO MEDINA,
                     MARIBEL CARRILLO, LUIS EMIRO MILLÁN, CARLOS MOUTHON, MABEL MORALES, JAIR HERNÁN LENIS, OLGA
                     LUCÍA COTAMO Y GILBERTO BUITRAGO</div>
                 <p class="title2 s2">rcn radio</p>
             </article>
             <article class="itemWOld">
                 <h3 class="title1 s1">Televisión</h3>
                 <!-- <hr class="gLine bg2"> -->
                 <h4 class="title1 s2">Los héroes de las torres eléctricas, Noticias RCN</h4>
                 <div class="title2 s1">GUILLERMO PRIETO ”PIRRY”</div>
                 <p class="title2 s2">canal rcn</p>
             </article>
             <article class="itemWOld">
                 <h3 class="title1 s1">Prensa</h3>
                 <!-- <hr class="gLine bg2"> -->
                 <h4 class="title1 s2">Los elefantes blancos</h4>
                 <div class="title2 s1">ERLY ROJAS, PATRICIA BOLÍVAR, CONSTANZA BRUNO, JULIA ARROYO, JUAN OÑATE,
                     BLANCA BRUNAL, GINNA MORELO, RAHOMIR BENÍTEZ, HENRY VELASCO, ÓSCAR SÁNCHEZ, MARIETA PÉREZ,
                     ANTONIO NAVARRO Jr., OLGA HURTADO, RAFAEL CERVANTES, KATRIZ CASTELLANOS, DOMINGO COGOLLO,
                     ARIANNA CÓRDOBA Y JUAN HURTADO </div>
                 <p class="title2 s2">el meridiano de córdoba</p>
             </article>
         </div>
     </section>
     <section class="contWinOld gAnimated fadeIn">
         <h2 class="title1">Columna de opinión</h2>
         <!-- <hr class="gLine w2 bg2"> -->
         <div class="listWOld">
             <article class="itemWOld">
                 <h3 class="title1 s1">Prensa</h3>
                 <!-- <hr class="gLine bg2"> -->
                 <h4 class="title1 s2">Soy zurdo a mucho honor</h4>
                 <div class="title2 s1">ÓSCAR COLLAZOS</div>
                 <p class="title2 s2">el tiempo</p>
             </article>
         </div>
     </section>
     <section class="contWinOld gAnimated fadeIn">
         <h2 class="title1">Caricatura</h2>
         <!-- <hr class="gLine w2 bg2"> -->
         <div class="listWOld">
             <article class="itemWOld">
                 <h3 class="title1 s1">Prensa</h3>
                 <!-- <hr class="gLine bg2"> -->
                 <h4 class="title1 s2">Tirofijo y avanzamos</h4>
                 <div class="title2 s1">MARIO HERNANDO OROZCO GALLEGO, ”MHEO”</div>
                 <p class="title2 s2">el país</p>
             </article>
         </div>
     </section>
     <section class="contWinOld gAnimated fadeIn">
         <h2 class="title1">Beca al periodismo joven</h2>
         <!-- <hr class="gLine w2 bg2"> -->
         <div class="listWOld">
             <article class="itemWOld">
                 <h3 class="title1 s1">Radio</h3>
                 <!-- <hr class="gLine bg2"> -->
                 <h4 class="title1 s2">Los relojes de los campanarios se niegan a desaparecer, Radio Sucesos RCN
                 </h4>
                 <div class="title2 s1">CARLOS JOSÉ TELLO</div>
                 <p class="title2 s2">rcn radio</p>
             </article>
             <article class="itemWOld">
                 <h3 class="title1 s1">Televisión</h3>
                 <!-- <hr class="gLine bg2"> -->
                 <h4 class="title1 s2">Paz premiada</h4>
                 <div class="title2 s1">CLAUDIA PATRICIA ARANGO</div>
                 <p class="title2 s2">teleantioquia</p>
             </article>
             <article class="itemWOld">
                 <h3 class="title1 s1">Prensa</h3>
                 <!-- <hr class="gLine bg2"> -->
                 <h4 class="title1 s2">Colombia positiva</h4>
                 <div class="title2 s1">JOSÉ MANUEL REVERÓN PEÑA</div>
                 <p class="title2 s2">revista cambio</p>
             </article>
         </div>
     </section>
 </div>