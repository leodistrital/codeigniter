<h5>En alianza con:</h5>
<?php foreach ($logos as $logo) :  ?>
    <img src="<?=$logo['img_agg']?>" alt="">
<?php endforeach; ?>