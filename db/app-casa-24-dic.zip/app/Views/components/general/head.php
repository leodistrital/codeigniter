<!DOCTYPE HTML>
<html lang="es-ES">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, maximum-scale=1.5, initial-scale=1">
    <!-- borrar a futuro -->
    <meta http-equiv="Expires" content="0">
    <meta http-equiv="Last-Modified" content="0">
    <meta http-equiv="Cache-Control" content="no-cache, mustrevalidate">
    <meta http-equiv="Pragma" content="no-cache">
    <title>RENAULT D-NET</title>

    <!--[if IE]>
    	<script>
            document.createElement('header');		document.createElement('footer');        document.createElement('section');
            document.createElement('nav');          document.createElement('article');       document.createElement('figure');
            document.createElement('figcaption');   document.createElement('aside');
        </script>
    <![endif]-->

    <link href="/images/site/favicon.ico" rel="shortcut icon">
    <link href="/css/reset.min.css" rel="stylesheet">
    <link href="/css/slick.css" rel="stylesheet">
    <link href="/css/colorbox.css" rel="stylesheet">
    <link href="/css/jquery-ui.structure.min.css" rel="stylesheet">
    <link href="/css/jquery.mCustomScrollbar.min.css" rel="stylesheet">
    <link href="/css/styles.css" rel="stylesheet">
    <link href="/css/fonts/fonts.css" rel="stylesheet">
</head>

<body>