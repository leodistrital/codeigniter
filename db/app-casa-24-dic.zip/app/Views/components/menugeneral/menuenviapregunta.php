 <nav class="menuRightTop">
     <a class="btnPreg" onclick="openPreg()&closeForm()">envía tus preguntas</a>
 </nav>