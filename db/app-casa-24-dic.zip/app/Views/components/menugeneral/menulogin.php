<div class="gLPage"></div>
<!--Page Header-->
<header class="pageHeader">
    <div>
        <h1>
            <a href="/">
                <span class="gHidden">RENAULT D-NET</span>
                <img src="images/site/renault_2021_simbolo.svg" alt="RENAULT D-NET">
            </a>
        </h1>
        <!--Main Menu-->
        <nav id="btnSalir" class="mainMenu">
            <ul>
                <li><a href="#"></a></li>
                <li><a href="#"></a></li>
                <li></li>
            </ul>
        </nav>
        <!--Fin Main Menu-->
    </div>
</header>
<!--Fin Page Header-->