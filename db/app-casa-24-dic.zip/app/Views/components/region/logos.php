<section class="prefooterHSection blanco">
    <div class="sliderPrefooter1 slick-initialized slick-slider">
        <div aria-live="polite" class="slick-list draggable">
            <div class="slick-track" role="listbox"
                style="opacity: 1; width: 1180px; transform: translate3d(0px, 0px, 0px);">
                <div class="gSlide slick-slide slick-current slick-active" data-slick-index="0" aria-hidden="false"
                    tabindex="-1" role="option" aria-describedby="slick-slide10" style="width: 1040px;">
                    <?php if( !empty($regioncontenido['logos'])){ ?>
                    <div class="vAlign">
                        <div>
                            <img src="<?=$regioncontenido['logos']?>" alt="">
                        </div>
                    </div>
                    <?php } ?>
                </div>
            </div>
        </div>
    </div>
</section>