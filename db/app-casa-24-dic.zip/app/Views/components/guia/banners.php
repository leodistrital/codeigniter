<section class="bannerGuiaHSection">
    <div class="sliderGuia">
        <?php
            $f=0; 
            // for($f=1; $f<3; $f++){  ?>
        <div class="gSlide">
            <div class="vAlign">
                <div>
                    <!-- <img style="width:100%" src="https://bogotamarket.com/images/guia/Banner_Guia_1.jpg" alt="banners"> -->
                    <!-- <img style="width:100%" src="https://bogotamarket.com/images/guia/latinseries.jpg" alt="banners"> -->
                    <img style="width:100%" src="https://bogotamarket.com/images/guia/linguaviva.jpg" alt="banners">
                </div>
            </div>

        </div>
        <div class="gSlide">
             <div class="vAlign">
                <div>
                    <!-- <img style="width:100%" src="https://bogotamarket.com/images/guia/ImanMusicBAMBannerALTA.jpg" alt="banners"> -->
                    <!-- <img style="width:100%" src="https://bogotamarket.com/images/guia/lapost.jpg" alt="banners"> -->
                    <img style="width:100%" src="https://bogotamarket.com/images/guia/congo.jpg" alt="banners">
                </div>
            </div>

        </div>

        <div class="gSlide">
             <div class="vAlign">
                <div>
                    <!-- <img style="width:100%" src="https://bogotamarket.com/images/guia/tis.jpeg" alt="banners"> -->
                    <img style="width:100%" src="https://bogotamarket.com/images/guia/sonata.jpg" alt="banners">
                </div>
            </div>
        </div>
<!-- 
        <div class="gSlide">
             <div class="vAlign">
                <div>
                    <img style="width:100%" src="https://bogotamarket.com/images/guia/otb.jpg" alt="banners">
                </div>
            </div>
        </div> -->


        <!-- <div class="gSlide">
            <div class="vAlign">
                <div>
                    <img style="width:100%" src="https://bogotamarket.com/images/guia/Banner_Prueba_2.jpg"
                        alt="banners">
                </div>
            </div>
        </div> -->
        <?php  //} ?>
    </div>
</section>