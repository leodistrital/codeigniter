<div class="contBtns">
    <!-- <button type="button" id='descargar-resultados' class="gButton btnGuia2">Guardar resultados</button> -->
</div>
<div class="contBtns">
    <button type="button" id='resent-resultados'
        class="gButton btnGuia2"><?=traduccirlabeldb('Restaurar Filtros'); ?></button>
</div>