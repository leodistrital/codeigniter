  <!--Extra-->
  <div class="sectExtra nop">
      <div class="maxW">
          <?php
       echo $this->include("components/convocatorias/listacategorias"); 
      echo $this->include("components/convocatorias/contenidocategoria");
      ?>
      </div>
  </div>
  <!--End Extra-->