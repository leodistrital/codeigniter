<!--Social networks-->
<div class="gSocialNet">
    <ul>
        <li><a href="<?=$redes['youtube']?>" target="_blank" class="icoSocial youtube-2022 youtube">youtube</a></li>
        <li><a href="<?=$redes['twitter']?>" target="_blank" class="icoSocial twitter-2022 twitter">twitter</a></li>
        <li><a href="<?=$redes['facebook']?>" target="_blank" class="icoSocial facebook-2022 facebook">facebook</a></li>
        <li><a href="<?=$redes['instagram']?>" target="_blank" class="icoSocial instagram-2022 instagram">instagram</a>
        </li>
    </ul>
</div>
<!--End Social networks-->