<li>
    <a href="#"><span><?= $menu['nom_mep']  ?></span></a>
    <ul>
        <li>
            <a href="/convocatorias/<?= $categoriainicial['slu_cac'] ?>">
                <span><?= $submenus['tit_edi'] ?></span>
            </a>
        </li>
    </ul>
</li>