  <nav class="mainMenu">
      <ul>
          <li class="home"><a href="index.php"><span>Inicio</span></a></li>
          <li>
              <a href="#"> <span>EL PREMIO</span></a>


              <ul>
                  <li><a
                          href="premio.php?cod=1$$-1$$-qm4nNEHfdmX0tyUjxz05wAXG3C6fwm&sel=1$$-1$$-qm4nNEHftm9uNBL12CXG3C6fwm">Nosotros</a>
                  </li>
                  <li><a href="premio.php?cod=XG3C6fwmX0tyUjxz05wAXG3C6fwm&sel=1$$-1$$-qm4nNEHftm9uNBL12CXG3C6fwm">Acerca
                          del Premio</a></li>
                  <li><a href="https://www.youtube.com/embed/Q4UJm1dqbX8?rel=0&autoplay=1&showinfo=0&controls=1"
                          class="openVideo" data-title="Premios a la Vida y Obra de un Periodista, 1976 - 2022">Premios
                          a la Vida y Obra de un Periodista, 1976 - 2022</a></li>
                  <li><a href="premio.php?cod=XG3C6fwm00tyUjxz05wAXG3C6fwm&sel=1$$-1$$-qm4nNEHftm9uNBL12CXG3C6fwm">T&#233;rminos
                          y condiciones</a></li>
                  <li><a href="premio.php?cod=XG3C6fwm10tyUjxz05wAXG3C6fwm&sel=1$$-1$$-qm4nNEHftm9uNBL12CXG3C6fwm">Consentimiento
                          para el tratamiento de datos personales</a></li>
              </ul>
          </li>
          <li>

              <a href="preguntas.php"> <span>PREGUNTAS FRECUENTES</span></a>

              <ul>
                  <li><a
                          href="preguntas.php?cod=XG3C6fwmX0tyUjxz05wAXG3C6fwm&sel=1$$-1$$-qm4nNEHfZn9uNBL12CXG3C6fwm">Calendario</a>
                  </li>
                  <li><a
                          href="preguntas.php?cod=XG3C6fwmY0tyUjxz05wAXG3C6fwm&sel=1$$-1$$-qm4nNEHfZn9uNBL12CXG3C6fwm">Inscripciones</a>
                  </li>
                  <li><a
                          href="preguntas.php?cod=XG3C6fwmZ0tyUjxz05wAXG3C6fwm&sel=1$$-1$$-qm4nNEHfZn9uNBL12CXG3C6fwm">Premios</a>
                  </li>
                  <li><a href="preguntas.php?cod=XG3C6fwm00tyUjxz05wAXG3C6fwm&sel=1$$-1$$-qm4nNEHfZn9uNBL12CXG3C6fwm">Criterios
                          de valoraci&#243;n</a></li>
                  <li><a href="preguntas.php?cod=XG3C6fwm20tyUjxz05wAXG3C6fwm&sel=1$$-1$$-qm4nNEHfZn9uNBL12CXG3C6fwm">C&#243mo
                          cargar trabajos de audio</a></li>
                  <li><a href="preguntas.php?cod=XG3C6fwm30tyUjxz05wAXG3C6fwm&sel=1$$-1$$-qm4nNEHfZn9uNBL12CXG3C6fwm">C&#243mo
                          cargar trabajos de video</a></li>
              </ul>
          </li>

          <li><a href="contacto.php"><span>Contacto</span></a></li>


      </ul>
  </nav>