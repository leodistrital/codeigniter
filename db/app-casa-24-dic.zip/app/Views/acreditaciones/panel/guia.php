<div class="listRegiones bg2 espSim">

    <div class="listAcred">
        <div class="listA">

            <article class="iAcred iAcredHome">
                <article class="iAcredLeft">
                    <article class="iRegiones">
                        <h2><?=traduccirlabeldb('Guía de industria'); ?></h2>
                    </article>
                </article>

                <article class="iAcredRight formAcred">
                    <div class="listReg">
                        <div class="listR">
                            <article class="iReg">
                                <ul class="btnPeq">
                                    <li class="cat2 acredBtn2">
                                        <a href="/panel/guia/participantes">
                                            <h2><?=traduccirlabeldb('Participantes'); ?></h2>
                                        </a>
                                    </li>
                                    <li class="cat2">
                                        <span
                                            class="labelBtns"><?=traduccirlabeldb('Información de contacto de las personas participantes en BAM.'); ?></span>
                                    </li>
                                </ul>
                                <ul class="btnPeq">
                                    <li class="cat2 acredBtn2">
                                        <a href="/panel/guia/empresas">
                                            <h2><?=traduccirlabeldb('Empresas'); ?></h2>
                                        </a>
                                    </li>
                                    <li class="cat2">
                                        <span
                                            class="labelBtns"><?=traduccirlabeldb('Empresas registradas y sus representantes.'); ?></span>
                                    </li>
                                </ul>
                                <ul class="btnPeq">
                                    <li class="cat2 acredBtn2">
                                        <a href="/panel/guia/favoritos">
                                            <h2><?=traduccirlabeldb('Favoritos'); ?></h2>
                                        </a>
                                    </li>
                                    <li class="cat2">
                                        <span
                                            class="labelBtns"><?=traduccirlabeldb('Sus contactos y empresas guardados.'); ?></span>
                                    </li>
                                </ul>
                            </article>
                        </div>
                    </div>
                </article>
            </article>
        </div>
    </div>
</div>
</div>
</div>
<!--End Extra-->
<br><br><br>