<?php

// print_r($datos);
// echo "leonardo";

/*
 <option value="1">Colombia</option>

<?php foreach ($todo as $item): ?>

<li><?= $item ?></li>

<?php endforeach ?>
*/
?>