<div class="ingBAM" id="divocultamuestra">
    <h1>Ingresar a BAM</h1>
    <p>Espacio exclusivo de usuarios registrados para acreditarse y consultar el espacio de industria.</p>
    <form id="formLogin" name="formLogin" method="POST" enctype="multipart/form-data">
        <div class="sectExtraInt">

            <section id="mainForm" class="contFormIng">
                <div class="gCenter">
                    <fieldset>
                        <label class="gLabel required">
                            <input type="text" name="lemail" id="lemail" placeholder="Usuario / Correo electrónico">
                        </label>
                        <label class="gLabel required">
                            <input type="password" name="lpass" id="lpass" placeholder="Contraseña">
                        </label>
                        <div class="contBtns">
                            <button type="submit" class="gButton btnING">Ingresar</button>
                        </div>
                    </fieldset>
                </div>
            </section>
            <span class="btnPass"><a href="/registro">Registrarme en el BAM</a></span>
            <span class="btnPass"><a href="/registro/olvide" class="openFancy" data-rel="relelenco">Olvidé mi
                    contraseña</a></span>
        </div>
    </form>
</div>